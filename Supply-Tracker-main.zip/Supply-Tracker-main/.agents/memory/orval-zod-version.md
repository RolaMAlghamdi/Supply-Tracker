---
name: Orval Zod version compatibility
description: Orval 8 may auto-detect Zod 4 syntax even when the workspace uses Zod 3.
---

When a pnpm workspace pins Zod 3, explicitly set `override.zod.version: 3` in the Orval config.

**Why:** Without the explicit setting, generated schemas can use `z.int()`, which fails typechecking against the workspace's Zod 3 package.

**How to apply:** Check the workspace catalog before changing generated schemas or upgrading Zod; prefer fixing the generator configuration and rerunning codegen.