# Supply Tracker 📦

## 📌 About the Project

Supply Tracker is a bilingual web platform designed to help engineers easily search for construction materials and components, check their availability, track restocking dates, and compare suppliers based on price and total cost.

The platform provides a centralized dashboard that organizes supply information and helps engineers make faster and more informed purchasing decisions.

The system supports both Arabic and English to provide an accessible experience for a wider range of users.

---

## 🎯 Problem

Engineers may face difficulties when searching for construction materials and components, especially when materials are unavailable or when they need to compare different suppliers.

They may also spend significant time manually tracking material availability, restocking dates, prices, and supplier information.

Supply Tracker aims to simplify this process by bringing the required information together in one platform.

---

## 💡 Solution

Supply Tracker provides a centralized platform where engineers can:

- 🔎 Search for construction materials and components.
- 📦 Check material availability.
- 🔄 Track restocking dates.
- 💰 Compare suppliers based on price.
- 📊 Compare the total cost.
- 📋 View material details and specifications.
- 📈 Monitor supply information through a dashboard.
- 🌐 Switch between Arabic and English.

---

## ✨ Key Features

### 🔍 Material Search
Search for construction materials and components and quickly access their information.

### 📦 Availability Tracking
View whether a material is currently available or unavailable.

### 🔄 Restock Tracking
Track expected restocking dates for unavailable materials.

### 💰 Supplier Comparison
Compare available suppliers based on:

- Material price
- Total cost
- Availability

### 📋 Material Details
View important information about each material, including specifications and pricing.

### 📊 Dashboard
A centralized dashboard provides a clear overview of supply information and helps users monitor materials efficiently.

### 🌐 Bilingual Interface
The platform supports:

- العربية 🇸🇦
- English 🇬🇧

Users can switch the interface language easily.

---

## 🎯 Target Users

The primary target users are:

- 👷 Engineers
- 🏗️ Construction professionals
- 📦 Procurement teams
- 🏢 Organizations involved in construction and supply management

---

## 🛠️ Technologies

The project is developed as a web application using modern web technologies.

- HTML
- CSS
- JavaScript
- Bootstrap
- Replit
- Git
- GitHub

---

## 🎨 Design

The platform uses a modern dashboard-based design focused on:

- Simplicity
- Clarity
- Easy navigation
- Efficient data presentation
- Responsive design

The interface is designed to help engineers quickly find the information they need without going through multiple sources.

---

## 🌐 Language Support

Supply Tracker supports a bilingual experience:

Arabic 🇸🇦 | English 🇬🇧

The interface can be switched between the two languages while maintaining the same functionality and information.

---

## 🚀 Future Improvements

Future versions of Supply Tracker may include:

- User authentication and accounts.
- Advanced filtering and search.
- Real-time supplier data.
- Database integration.
- Supplier management.
- Notifications for restocking dates.
- Advanced analytics and reports.
- Personalized recommendations.
- Integration with construction material suppliers.

---

## 👥 Team

This project was developed collaboratively by a student team.

### Team Members

- Team Member 1
- Team Member 2
- Team Member 3
- Team Member 4

---

## 📄 Project Purpose

Supply Tracker was developed as a project to explore how digital solutions can simplify construction supply tracking and help engineers make faster and more informed decisions.
