import { Router, type IRouter } from "express";
import {
  CreateAvailabilityAlertBody,
  CreateAvailabilityAlertResponse,
  GetDashboardSummaryResponse,
  GetMaterialParams,
  GetMaterialResponse,
  ListAvailabilityAlertsResponse,
  ListMaterialsQueryParams,
  ListMaterialsResponse,
} from "@workspace/api-zod";

type Material = {
  id: number;
  nameEn: string;
  nameAr: string;
  category: string;
  categoryAr: string;
  sku: string;
  unit: string;
  stockStatus: "in_stock" | "low_stock" | "out_of_stock";
  nextRestock: string | null;
  lastUpdated: string;
  supplierCount: number;
  minPrice: number;
  descriptionEn: string;
  descriptionAr: string;
};

type SupplierOffer = {
  id: number;
  supplierName: string;
  supplierNameAr: string;
  location: string;
  distanceKm: number;
  price: number;
  shipping: number;
  totalCost: number;
  currency: string;
  inStock: boolean;
  stockQuantity: number | null;
  deliveryDays: number;
  rating: number;
  verified: boolean;
};

type Alert = {
  id: number;
  materialId: number;
  materialNameEn: string;
  materialNameAr: string;
  createdAt: string;
  status: "active" | "fulfilled";
};

const lastUpdated = "2026-08-11T08:30:00.000Z";

const materials: Material[] = [
  {
    id: 1,
    nameEn: "Portland Cement 42.5",
    nameAr: "أسمنت بورتلاندي 42.5",
    category: "Cement & Concrete",
    categoryAr: "الأسمنت والخرسانة",
    sku: "CEM-425-50",
    unit: "50 kg bag",
    stockStatus: "in_stock",
    nextRestock: null,
    lastUpdated,
    supplierCount: 8,
    minPrice: 14.5,
    descriptionEn: "High-strength Portland cement for structural and general construction work.",
    descriptionAr: "أسمنت بورتلاندي عالي المقاومة للأعمال الإنشائية والاستخدامات العامة.",
  },
  {
    id: 2,
    nameEn: "Rebar Steel 16mm",
    nameAr: "حديد تسليح 16 مم",
    category: "Steel & Metals",
    categoryAr: "الحديد والمعادن",
    sku: "REB-16-12",
    unit: "12 m bar",
    stockStatus: "low_stock",
    nextRestock: "2026-08-16T00:00:00.000Z",
    lastUpdated,
    supplierCount: 5,
    minPrice: 21.8,
    descriptionEn: "Grade 60 deformed rebar for reinforced concrete structures.",
    descriptionAr: "حديد تسليح مضلع درجة 60 للهياكل الخرسانية المسلحة.",
  },
  {
    id: 3,
    nameEn: "Insulation Board XPS",
    nameAr: "ألواح عزل XPS",
    category: "Insulation",
    categoryAr: "العزل",
    sku: "INS-XPS-50",
    unit: "120 × 60 cm board",
    stockStatus: "out_of_stock",
    nextRestock: "2026-08-20T00:00:00.000Z",
    lastUpdated,
    supplierCount: 3,
    minPrice: 18.2,
    descriptionEn: "Extruded polystyrene insulation boards, 50mm thickness, for thermal protection.",
    descriptionAr: "ألواح عزل من البوليسترين المبثوق بسماكة 50 مم للحماية الحرارية.",
  },
  {
    id: 4,
    nameEn: "PVC Drainage Pipe 110mm",
    nameAr: "أنبوب تصريف PVC 110 مم",
    category: "Plumbing",
    categoryAr: "السباكة",
    sku: "PVC-110-6",
    unit: "6 m length",
    stockStatus: "in_stock",
    nextRestock: null,
    lastUpdated,
    supplierCount: 6,
    minPrice: 9.75,
    descriptionEn: "Durable PVC drainage pipe suitable for underground and building drainage systems.",
    descriptionAr: "أنبوب تصريف PVC متين مناسب لأنظمة الصرف الأرضية وصرف المباني.",
  },
  {
    id: 5,
    nameEn: "Ceramic Floor Tile",
    nameAr: "بلاط أرضيات سيراميك",
    category: "Finishes",
    categoryAr: "التشطيبات",
    sku: "TIL-60-60",
    unit: "60 × 60 cm box",
    stockStatus: "in_stock",
    nextRestock: null,
    lastUpdated,
    supplierCount: 11,
    minPrice: 32.4,
    descriptionEn: "Commercial-grade ceramic floor tile with a low-maintenance matte finish.",
    descriptionAr: "بلاط أرضيات سيراميك تجاري بلمسة مطفية سهلة الصيانة.",
  },
  {
    id: 6,
    nameEn: "Ready-Mix Concrete C30",
    nameAr: "خرسانة جاهزة C30",
    category: "Cement & Concrete",
    categoryAr: "الأسمنت والخرسانة",
    sku: "RMC-C30-1",
    unit: "cubic metre",
    stockStatus: "low_stock",
    nextRestock: "2026-08-13T00:00:00.000Z",
    lastUpdated,
    supplierCount: 4,
    minPrice: 245,
    descriptionEn: "C30 ready-mix concrete for foundations, slabs, and structural pours.",
    descriptionAr: "خرسانة جاهزة C30 للأساسات والبلاطات والصبات الإنشائية.",
  },
];

const offers: Record<number, SupplierOffer[]> = {
  1: [
    { id: 101, supplierName: "Gulf Build Materials", supplierNameAr: "مواد الخليج للبناء", location: "Riyadh", distanceKm: 12.4, price: 14.5, shipping: 0, totalCost: 14.5, currency: "SAR", inStock: true, stockQuantity: 4200, deliveryDays: 1, rating: 4.8, verified: true },
    { id: 102, supplierName: "Al Omran Trading", supplierNameAr: "العمران للتجارة", location: "Riyadh", distanceKm: 7.8, price: 14.9, shipping: 1.2, totalCost: 16.1, currency: "SAR", inStock: true, stockQuantity: 1800, deliveryDays: 1, rating: 4.6, verified: true },
    { id: 103, supplierName: "BuildMart", supplierNameAr: "بيلدمارت", location: "Al Kharj", distanceKm: 68, price: 13.95, shipping: 4.5, totalCost: 18.45, currency: "SAR", inStock: true, stockQuantity: 900, deliveryDays: 2, rating: 4.3, verified: false },
  ],
  2: [
    { id: 201, supplierName: "Saudi Steel Hub", supplierNameAr: "مركز الحديد السعودي", location: "Riyadh", distanceKm: 18.2, price: 21.8, shipping: 0, totalCost: 21.8, currency: "SAR", inStock: true, stockQuantity: 180, deliveryDays: 2, rating: 4.9, verified: true },
    { id: 202, supplierName: "Gulf Metal Co.", supplierNameAr: "شركة الخليج للمعادن", location: "Dammam", distanceKm: 388, price: 20.9, shipping: 12, totalCost: 32.9, currency: "SAR", inStock: true, stockQuantity: 600, deliveryDays: 4, rating: 4.5, verified: true },
    { id: 203, supplierName: "Al Waha Steel", supplierNameAr: "حديد الواحة", location: "Riyadh", distanceKm: 24.5, price: 22.4, shipping: 1.5, totalCost: 23.9, currency: "SAR", inStock: false, stockQuantity: 0, deliveryDays: 7, rating: 4.2, verified: false },
  ],
  3: [
    { id: 301, supplierName: "ThermoBuild", supplierNameAr: "ثيرموبيلد", location: "Riyadh", distanceKm: 22.1, price: 18.2, shipping: 3.8, totalCost: 22, currency: "SAR", inStock: false, stockQuantity: 0, deliveryDays: 10, rating: 4.7, verified: true },
    { id: 302, supplierName: "Insulation House", supplierNameAr: "بيت العزل", location: "Jeddah", distanceKm: 949, price: 17.6, shipping: 18, totalCost: 35.6, currency: "SAR", inStock: false, stockQuantity: 0, deliveryDays: 12, rating: 4.4, verified: true },
  ],
  4: [
    { id: 401, supplierName: "PlumbPro", supplierNameAr: "بلَمب برو", location: "Riyadh", distanceKm: 9.3, price: 10.1, shipping: 0, totalCost: 10.1, currency: "SAR", inStock: true, stockQuantity: 760, deliveryDays: 1, rating: 4.6, verified: true },
    { id: 402, supplierName: "Afaq Building Supply", supplierNameAr: "آفاق لمواد البناء", location: "Riyadh", distanceKm: 31, price: 9.75, shipping: 2.6, totalCost: 12.35, currency: "SAR", inStock: true, stockQuantity: 320, deliveryDays: 2, rating: 4.3, verified: false },
  ],
  5: [
    { id: 501, supplierName: "Surface Studio", supplierNameAr: "استوديو الأسطح", location: "Riyadh", distanceKm: 15.8, price: 32.4, shipping: 0, totalCost: 32.4, currency: "SAR", inStock: true, stockQuantity: 240, deliveryDays: 2, rating: 4.8, verified: true },
    { id: 502, supplierName: "HomeCraft Trade", supplierNameAr: "هوم كرافت للتجارة", location: "Riyadh", distanceKm: 41.2, price: 30.9, shipping: 5.5, totalCost: 36.4, currency: "SAR", inStock: true, stockQuantity: 510, deliveryDays: 3, rating: 4.5, verified: true },
  ],
  6: [
    { id: 601, supplierName: "ReadyPour", supplierNameAr: "ريدي بور", location: "Riyadh", distanceKm: 14.3, price: 245, shipping: 0, totalCost: 245, currency: "SAR", inStock: true, stockQuantity: 36, deliveryDays: 1, rating: 4.9, verified: true },
    { id: 602, supplierName: "Concrete Works", supplierNameAr: "أعمال الخرسانة", location: "Riyadh", distanceKm: 26.7, price: 238, shipping: 15, totalCost: 253, currency: "SAR", inStock: true, stockQuantity: 22, deliveryDays: 2, rating: 4.4, verified: true },
  ],
};

let alerts: Alert[] = [
  { id: 1, materialId: 2, materialNameEn: materials[1].nameEn, materialNameAr: materials[1].nameAr, createdAt: "2026-08-10T07:45:00.000Z", status: "active" },
  { id: 2, materialId: 3, materialNameEn: materials[2].nameEn, materialNameAr: materials[2].nameAr, createdAt: "2026-08-09T14:20:00.000Z", status: "active" },
];

const router: IRouter = Router();

router.get("/dashboard/summary", (_req, res) => {
  const data = GetDashboardSummaryResponse.parse({
    totalMaterials: materials.length,
    inStock: materials.filter((material) => material.stockStatus === "in_stock").length,
    lowStock: materials.filter((material) => material.stockStatus === "low_stock").length,
    outOfStock: materials.filter((material) => material.stockStatus === "out_of_stock").length,
    trackedAlerts: alerts.filter((alert) => alert.status === "active").length,
    averageSavings: 8.6,
  });
  res.json(data);
});

router.get("/materials", (req, res) => {
  const parsed = ListMaterialsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid material filters" });
    return;
  }
  const { q, category, availability } = parsed.data;
  const normalizedQuery = q?.trim().toLocaleLowerCase();
  const result = materials
    .filter((material) => !normalizedQuery || [material.nameEn, material.nameAr, material.sku].some((value) => value.toLocaleLowerCase().includes(normalizedQuery)))
    .filter((material) => !category || category === "all" || material.category === category)
    .filter((material) => !availability || availability === "all" || material.stockStatus === availability)
    .map(({ descriptionEn: _descriptionEn, descriptionAr: _descriptionAr, ...material }) => material);
  res.json(ListMaterialsResponse.parse(result));
});

router.get("/materials/:id", (req, res) => {
  const parsed = GetMaterialParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid material id" });
    return;
  }
  const material = materials.find((item) => item.id === parsed.data.id);
  if (!material) {
    res.status(404).json({ error: "Material not found" });
    return;
  }
  res.json(GetMaterialResponse.parse({ ...material, offers: offers[material.id] ?? [] }));
});

router.get("/availability-alerts", (_req, res) => {
  res.json(ListAvailabilityAlertsResponse.parse(alerts));
});

router.post("/availability-alerts", (req, res) => {
  const parsed = CreateAvailabilityAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "A material id is required" });
    return;
  }
  const material = materials.find((item) => item.id === parsed.data.materialId);
  if (!material) {
    res.status(404).json({ error: "Material not found" });
    return;
  }
  const existing = alerts.find((alert) => alert.materialId === material.id && alert.status === "active");
  if (existing) {
    res.status(201).json(CreateAvailabilityAlertResponse.parse(existing));
    return;
  }
  const alert: Alert = {
    id: Math.max(0, ...alerts.map((item) => item.id)) + 1,
    materialId: material.id,
    materialNameEn: material.nameEn,
    materialNameAr: material.nameAr,
    createdAt: new Date().toISOString(),
    status: "active",
  };
  alerts = [alert, ...alerts];
  res.status(201).json(CreateAvailabilityAlertResponse.parse(alert));
});

export default router;