import { createContext, type ReactNode, useContext, useEffect, useMemo, useState } from 'react';
import { BellRing, Boxes, ChevronDown, CircleUserRound, LayoutDashboard, Menu, Search, X } from 'lucide-react';
import { Link, useLocation } from 'wouter';

type Language = 'en' | 'ar';
const LanguageContext = createContext<{ language: Language; setLanguage: (language: Language) => void }>({ language: 'en', setLanguage: () => undefined });
export function useLanguage() { return useContext(LanguageContext); }
export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem('buildsupply-language') as Language) || 'en');
  useEffect(() => {
    localStorage.setItem('buildsupply-language', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);
  const value = useMemo(() => ({ language, setLanguage }), [language]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

const navItems = [
  { href: '/', label: 'Overview', ar: 'نظرة عامة', icon: LayoutDashboard },
  { href: '/materials', label: 'Materials', ar: 'المواد', icon: Boxes },
  { href: '/alerts', label: 'Availability alerts', ar: 'تنبيهات التوفر', icon: BellRing },
];

export function BuildSupplyShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { language, setLanguage } = useLanguage();
  const isActive = (href: string) => href === '/' ? location === '/' : location.startsWith(href);
  return <div className="app-frame">
    <aside className={`app-sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="sidebar-brand">
        <div className="brand-mark">B<span>/</span>S</div>
        <div><p className="brand-name">BuildSupply</p><p className="brand-caption">{language === 'ar' ? 'عمليات الموقع' : 'SITE OPERATIONS'}</p></div>
        <button className="sidebar-close" onClick={() => setMobileOpen(false)} aria-label="Close menu" data-testid="button-close-menu"><X size={19} /></button>
      </div>
      <div className="sidebar-rule" />
      <p className="sidebar-label">{language === 'ar' ? 'مساحة العمل' : 'WORKSPACE'}</p>
      <nav className="sidebar-nav">
        {navItems.map(({ href, label, ar, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`sidebar-link ${isActive(href) ? 'sidebar-link-active' : ''}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>
          <Icon size={18} strokeWidth={isActive(href) ? 2.3 : 1.8} /><span>{language === 'ar' ? ar : label}</span>{href === '/alerts' && <span className="nav-pulse" />}
        </Link>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="site-status"><span className="live-dot" /><div><p>{language === 'ar' ? 'الخدمات متصلة' : 'Services connected'}</p><span>API / ERP</span></div></div>
        <div className="account-card"><div className="avatar">AK</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{language === 'ar' ? 'أحمد الخطيب' : 'Ahmed Al-Khatib'}</p><p className="truncate text-xs text-sidebar-muted">{language === 'ar' ? 'مهندس مشتريات' : 'Procurement engineer'}</p></div><ChevronDown size={15} className="text-sidebar-muted" /></div>
      </div>
    </aside>
    {mobileOpen && <button className="sidebar-overlay" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-overlay" />}
    <main className="app-main">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open menu" data-testid="button-open-menu"><Menu size={21} /></button>
        <div className="breadcrumb"><span className="breadcrumb-muted">BuildSupply</span><span>/</span><span>{language === 'ar' ? 'عمليات الموقع' : 'Site operations'}</span></div>
        <div className="topbar-actions">
          <button className="quick-search" onClick={() => { if (location !== '/materials') window.history.pushState({}, '', '/materials'); window.dispatchEvent(new PopStateEvent('popstate')); }} data-testid="button-quick-search"><Search size={16} /><span>{language === 'ar' ? 'بحث في المواد' : 'Search materials'}</span><kbd>⌘ K</kbd></button>
          <button className="language-toggle" onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')} data-testid="button-language-toggle"><span className={language === 'en' ? 'language-active' : ''}>EN</span><span>/</span><span className={language === 'ar' ? 'language-active' : ''}>ع</span></button>
          <button className="icon-button notification-button" aria-label="Notifications" data-testid="button-notifications"><BellRing size={18} /><i /></button>
          <div className="topbar-user"><div className="avatar avatar-small">AK</div><CircleUserRound size={16} className="user-chevron" /></div>
        </div>
      </header>
      <div className="page-content">{children}</div>
    </main>
  </div>;
}