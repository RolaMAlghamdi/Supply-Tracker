import { AlertTriangle, ArrowUpRight, Check, Clock3, MapPin, PackageOpen, RefreshCw, ShieldCheck, Truck } from 'lucide-react';
import { Link } from 'wouter';
import type { Material, SupplierOffer } from '@workspace/api-client-react';
import { useLanguage } from './buildsupply-shell';

export function StatusBadge({ status }: { status: Material['stockStatus'] }) {
  const labels = {
    in_stock: { en: 'In stock', ar: 'متوفر', className: 'status-in' },
    low_stock: { en: 'Low stock', ar: 'مخزون منخفض', className: 'status-low' },
    out_of_stock: { en: 'Out of stock', ar: 'غير متوفر', className: 'status-out' },
  }[status];
  const { language } = useLanguage();
  return <span className={`status-badge ${labels.className}`} data-testid={`status-material-${status}`}>{language === 'ar' ? labels.ar : labels.en}</span>;
}

export function AlertStatusBadge({ status }: { status: 'active' | 'fulfilled' }) {
  const { language } = useLanguage();
  return <span className={`status-badge ${status === 'active' ? 'status-low' : 'status-in'}`} data-testid={`status-alert-${status}`}>
    {status === 'active' ? (language === 'ar' ? 'مراقب' : 'Tracking') : (language === 'ar' ? 'تم التوفير' : 'Fulfilled')}
  </span>;
}

export function MaterialRow({ material, compact = false }: { material: Material; compact?: boolean }) {
  const { language } = useLanguage();
  const name = language === 'ar' ? material.nameAr : material.nameEn;
  const category = language === 'ar' ? material.categoryAr : material.category;
  return (
    <Link href={`/materials/${material.id}`} className={`material-row ${compact ? 'material-row-compact' : ''}`} data-testid={`link-material-${material.id}`}>
      <div className="material-icon"><PackageOpen size={18} strokeWidth={1.8} /></div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate font-semibold text-ink">{name}</p>
          <span className="hidden font-mono text-[10px] text-quiet sm:inline">{material.sku}</span>
        </div>
        <p className="mt-1 text-xs text-quiet">{category} · {material.supplierCount} {language === 'ar' ? 'موردين' : 'suppliers'}</p>
      </div>
      <div className="flex shrink-0 items-center gap-3">
        {!compact && <div className="hidden text-right sm:block"><p className="font-mono text-sm font-semibold text-ink">{formatPrice(material.minPrice)}</p><p className="text-[11px] text-quiet">/{material.unit}</p></div>}
        <StatusBadge status={material.stockStatus} />
        <ArrowUpRight size={16} className="text-quiet transition-transform group-hover:translate-x-0.5" />
      </div>
    </Link>
  );
}

export function OfferRow({ offer, best = false }: { offer: SupplierOffer; best?: boolean }) {
  const { language } = useLanguage();
  return (
    <div className={`offer-row ${best ? 'offer-best' : ''}`} data-testid={`row-offer-${offer.id}`}>
      <div className="offer-rank">{best ? <Check size={15} /> : <span>{offer.id}</span>}</div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <p className="font-semibold text-ink">{language === 'ar' ? offer.supplierNameAr : offer.supplierName}</p>
          {offer.verified && <span className="verified-mark"><ShieldCheck size={11} /> {language === 'ar' ? 'موثق' : 'Verified'}</span>}
        </div>
        <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-quiet">
          <span className="inline-flex items-center gap-1"><MapPin size={12} />{offer.location} · {offer.distanceKm} km</span>
          <span className="inline-flex items-center gap-1"><Truck size={12} />{offer.deliveryDays} {language === 'ar' ? 'أيام توصيل' : 'days delivery'}</span>
          <span>★ {offer.rating.toFixed(1)}</span>
        </div>
      </div>
      <div className="text-right">
        <p className="font-mono text-base font-semibold text-ink">{formatPrice(offer.totalCost)} <span className="text-[10px] font-normal text-quiet">{offer.currency}</span></p>
        <p className={`mt-1 text-[11px] ${offer.inStock ? 'text-teal' : 'text-rust'}`}>{offer.inStock ? (offer.stockQuantity ? `${offer.stockQuantity} ${language === 'ar' ? 'متاح' : 'available'}` : (language === 'ar' ? 'متوفر' : 'In stock')) : (language === 'ar' ? 'طلب مسبق' : 'Pre-order')}</p>
      </div>
    </div>
  );
}

export function LoadingRows({ count = 4 }: { count?: number }) {
  return <div className="space-y-2" aria-label="Loading"><div className="skeleton-line mb-4 h-4 w-32" />{Array.from({ length: count }).map((_, index) => <div className="skeleton-row" key={index}><div className="skeleton-circle" /><div className="flex-1 space-y-2"><div className="skeleton-line h-3 w-2/5" /><div className="skeleton-line h-2 w-1/4" /></div><div className="skeleton-line h-5 w-20" /></div>)}</div>;
}

export function ErrorState({ onRetry, detail = false }: { onRetry: () => void; detail?: boolean }) {
  const { language } = useLanguage();
  return <div className={`empty-state ${detail ? 'min-h-[340px]' : ''}`} role="alert" data-testid="state-error">
    <div className="empty-icon error-icon"><AlertTriangle size={22} /></div>
    <h3>{language === 'ar' ? 'تعذر تحميل البيانات' : 'We could not load this view'}</h3>
    <p>{language === 'ar' ? 'تحقق من الاتصال وحاول مرة أخرى.' : 'Check your connection and try again.'}</p>
    <button onClick={onRetry} className="button-secondary mt-4" data-testid="button-retry"><RefreshCw size={15} /> {language === 'ar' ? 'إعادة المحاولة' : 'Retry'}</button>
  </div>;
}

export function EmptyState({ title, copy }: { title: string; copy: string }) {
  return <div className="empty-state" data-testid="state-empty">
    <div className="empty-icon"><Clock3 size={22} /></div><h3>{title}</h3><p>{copy}</p>
  </div>;
}

export function formatPrice(value: number) {
  return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}

export function formatDate(value: string | null | undefined, language: 'en' | 'ar') {
  if (!value) return language === 'ar' ? 'غير محدد' : 'Not scheduled';
  return new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(value));
}