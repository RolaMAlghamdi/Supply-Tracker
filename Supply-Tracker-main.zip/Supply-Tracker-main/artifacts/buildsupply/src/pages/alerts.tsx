import { BellRing, CalendarDays, CheckCircle2, PackageOpen, Radar, Search } from 'lucide-react';
import { useListAvailabilityAlerts } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { useLanguage } from '@/components/buildsupply-shell';
import { AlertStatusBadge, EmptyState, ErrorState, formatDate, LoadingRows } from '@/components/workspace-primitives';

export default function Alerts() {
  const { language } = useLanguage();
  const copy = language === 'ar';
  const query = useListAvailabilityAlerts({ query: { queryKey: ['/api/availability-alerts'] } });
  const alerts = query.data ?? [];
  const active = alerts.filter((alert) => alert.status === 'active');
  const fulfilled = alerts.filter((alert) => alert.status === 'fulfilled');
  return <div className="workspace-page">
    <section className="page-heading"><div><p className="eyebrow"><span className="eyebrow-line" />{copy ? 'مركز الإشعارات' : 'NOTIFICATION CENTER'}</p><h1>{copy ? 'تنبيهات التوفر' : 'Availability alerts'}</h1><p className="heading-copy">{copy ? 'لا حاجة لتذكر ما ينقص الموقع. نحن نراقبه عنك.' : 'You do not need to remember what the site is missing. We watch it for you.'}</p></div><div className="alert-summary"><div><span className="summary-number">{active.length}</span><span>{copy ? 'نشط' : 'active'}</span></div><div><span className="summary-number summary-muted">{fulfilled.length}</span><span>{copy ? 'تم التوفير' : 'fulfilled'}</span></div></div></section>
    <section className="alert-banner"><div className="alert-banner-icon"><Radar size={22} /></div><div><p className="font-semibold text-ink">{copy ? 'مراقبة تلقائية للتوفر' : 'Availability is monitored automatically'}</p><p className="mt-1 text-sm text-quiet">{copy ? 'سنقوم بتحديث حالة التنبيه عندما يؤكد أحد الموردين مخزوناً جديداً.' : 'We update an alert when a supplier confirms new stock.'}</p></div><BellRing size={19} className="mr-1 text-amber" /></section>
    <section className="panel alerts-table-panel"><div className="panel-header"><div><p className="eyebrow">{copy ? 'قائمة المتابعة' : 'WATCHLIST'}</p><h2>{copy ? 'المواد التي تراقبها' : 'Materials you are watching'}</h2></div><span className="table-count">{alerts.length} {copy ? 'إجمالي' : 'total'}</span></div>{query.isLoading ? <LoadingRows count={5} /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : alerts.length ? <div className="alerts-table">{alerts.map((alert) => <Link href={`/materials/${alert.materialId}`} className="tracked-row" key={alert.id} data-testid={`link-tracked-alert-${alert.id}`}><div className="tracked-icon">{alert.status === 'active' ? <BellRing size={16} /> : <CheckCircle2 size={16} />}</div><div className="min-w-0 flex-1"><p className="font-semibold text-ink">{copy ? alert.materialNameAr : alert.materialNameEn}</p><p className="mt-1 font-mono text-[11px] text-quiet">M-{String(alert.materialId).padStart(4, '0')}</p></div><div className="tracked-date"><CalendarDays size={14} /><span>{formatDate(alert.createdAt, language)}</span></div><AlertStatusBadge status={alert.status} /></Link>)}</div> : <EmptyState title={copy ? 'لا توجد تنبيهات بعد' : 'No alerts yet'} copy={copy ? 'افتح أي مادة واختر تتبع التوفر لتظهر هنا.' : 'Open any material and choose track availability to see it here.'} />}</section>
    <div className="alerts-footer-note"><Search size={15} /><span>{copy ? 'تحتاج إلى العثور على مادة جديدة؟' : 'Need to find another material?'}</span><Link href="/materials" className="text-link" data-testid="link-alerts-to-materials">{copy ? 'تصفح الكتالوج' : 'Browse the catalog'}</Link></div>
  </div>;
}