import { ArrowDownRight, ArrowRight, BellRing, Boxes, CircleDollarSign, PackageCheck, Radar, Search, TrendingDown } from 'lucide-react';
import { Link } from 'wouter';
import { useGetDashboardSummary, useListAvailabilityAlerts, useListMaterials } from '@workspace/api-client-react';
import { useLanguage } from '@/components/buildsupply-shell';
import { EmptyState, ErrorState, formatDate, formatPrice, LoadingRows, MaterialRow, StatusBadge } from '@/components/workspace-primitives';

function StatCard({ label, value, detail, icon: Icon, tone, loading }: { label: string; value: string | number; detail: string; icon: typeof Boxes; tone: string; loading?: boolean }) {
  return <div className={`stat-card ${tone}`} data-testid={`card-stat-${tone}`}>
    <div className="stat-card-top"><div className="stat-icon"><Icon size={18} /></div><span className="stat-detail">{detail}</span></div>
    {loading ? <><div className="skeleton-line mt-4 h-8 w-20" /><div className="skeleton-line mt-2 h-3 w-28" /></> : <><p className="stat-value" data-testid={`value-stat-${tone}`}>{value}</p><p className="stat-label">{label}</p></>}
  </div>;
}

export default function Dashboard() {
  const { language } = useLanguage();
  const summaryQuery = useGetDashboardSummary({ query: { queryKey: ['/api/dashboard/summary'] } });
  const materialsQuery = useListMaterials({ availability: 'all' }, { query: { queryKey: ['/api/materials', { availability: 'all' }] } });
  const alertsQuery = useListAvailabilityAlerts({ query: { queryKey: ['/api/availability-alerts'] } });
  const summary = summaryQuery.data;
  const materials = materialsQuery.data ?? [];
  const alerts = alertsQuery.data ?? [];
  const stockSnapshot = materials.filter((item) => item.stockStatus !== 'out_of_stock').slice(0, 5);
  const opportunities = [...materials].sort((a, b) => a.minPrice - b.minPrice).slice(0, 4);
  const copy = language === 'ar';
  return <div className="workspace-page">
    <section className="page-heading dashboard-heading">
      <div><p className="eyebrow"><span className="eyebrow-line" />{copy ? 'الثلاثاء، ٢١ مايو ٢٠٢٤' : 'TUESDAY, 21 MAY 2024'}</p><h1>{copy ? 'صباح الخير، أحمد' : 'Good morning, Ahmed'}</h1><p className="heading-copy">{copy ? 'كل شيء تحت السيطرة. إليك ما يحدث في سلسلة التوريد اليوم.' : "Everything is in view. Here's what is moving across your supply chain today."}</p></div>
      <Link href="/materials" className="button-primary" data-testid="link-source-materials"><Search size={16} />{copy ? 'تصفح المواد' : 'Source materials'}<ArrowRight size={15} /></Link>
    </section>

    {summaryQuery.isError ? <ErrorState onRetry={() => summaryQuery.refetch()} /> : <div className="stats-grid">
      <StatCard label={copy ? 'إجمالي المواد' : 'Materials tracked'} value={summary?.totalMaterials ?? 0} detail="CATALOG" icon={Boxes} tone="stat-navy" loading={summaryQuery.isLoading} />
      <StatCard label={copy ? 'متوفر الآن' : 'Available now'} value={summary?.inStock ?? 0} detail={`${summary ? Math.round(summary.inStock / Math.max(summary.totalMaterials, 1) * 100) : 0}%`} icon={PackageCheck} tone="stat-teal" loading={summaryQuery.isLoading} />
      <StatCard label={copy ? 'تنبيهات نشطة' : 'Active alerts'} value={summary?.trackedAlerts ?? 0} detail="MONITORING" icon={Radar} tone="stat-amber" loading={summaryQuery.isLoading} />
      <StatCard label={copy ? 'متوسط التوفير' : 'Average saving'} value={summary ? `${formatPrice(summary.averageSavings)}%` : '0%'} detail="VS MARKET" icon={CircleDollarSign} tone="stat-rust" loading={summaryQuery.isLoading} />
    </div>}

    <div className="dashboard-grid">
      <section className="panel snapshot-panel">
        <div className="panel-header"><div><p className="eyebrow">{copy ? 'الآن' : 'RIGHT NOW'}</p><h2>{copy ? 'لقطة التوفر' : 'Availability snapshot'}</h2></div><Link href="/materials" className="text-link" data-testid="link-view-catalog">{copy ? 'عرض الكتالوج' : 'View catalog'} <ArrowRight size={14} /></Link></div>
        {materialsQuery.isLoading ? <LoadingRows count={4} /> : materialsQuery.isError ? <ErrorState onRetry={() => materialsQuery.refetch()} /> : stockSnapshot.length ? <div className="material-list">{stockSnapshot.map((material) => <MaterialRow key={material.id} material={material} compact />)}</div> : <EmptyState title={copy ? 'لا توجد مواد بعد' : 'No materials in view'} copy={copy ? 'ستظهر المواد عندما تصل بيانات المخزون.' : 'Materials will appear here when inventory data arrives.'} />}
        <div className="snapshot-footer"><div className="stock-rail"><span style={{ width: `${summary ? (summary.inStock / Math.max(summary.totalMaterials, 1)) * 100 : 0}%` }} /><i style={{ width: `${summary ? (summary.lowStock / Math.max(summary.totalMaterials, 1)) * 100 : 0}%` }} /></div><span>{summary?.inStock ?? 0} {copy ? 'متوفر من' : 'available of'} {summary?.totalMaterials ?? 0}</span></div>
      </section>
      <section className="panel alerts-panel">
        <div className="panel-header"><div><p className="eyebrow">{copy ? 'مراقبتك' : 'YOUR WATCHLIST'}</p><h2>{copy ? 'آخر التنبيهات' : 'Recent alerts'}</h2></div><Link href="/alerts" className="round-link" aria-label="View alerts" data-testid="link-view-alerts"><ArrowRight size={16} /></Link></div>
        {alertsQuery.isLoading ? <LoadingRows count={3} /> : alertsQuery.isError ? <ErrorState onRetry={() => alertsQuery.refetch()} /> : alerts.slice(0, 4).length ? <div className="alert-list">{alerts.slice(0, 4).map((alert) => <Link href={`/materials/${alert.materialId}`} className="alert-row" key={alert.id} data-testid={`link-alert-${alert.id}`}><div className="alert-signal"><BellRing size={15} /></div><div className="min-w-0 flex-1"><p className="truncate font-semibold text-ink">{copy ? alert.materialNameAr : alert.materialNameEn}</p><p className="mt-1 text-xs text-quiet">{formatDate(alert.createdAt, language)} · {alert.status === 'active' ? (copy ? 'بانتظار التوفر' : 'Waiting for stock') : (copy ? 'تم التوفير' : 'Now available')}</p></div><span className={alert.status === 'active' ? 'alert-dot' : 'alert-check'}>{alert.status === 'active' ? '●' : '✓'}</span></Link>)}</div> : <EmptyState title={copy ? 'قائمة المراقبة هادئة' : 'Watchlist is quiet'} copy={copy ? 'تتبع مادة عندما تحتاج إشعاراً.' : 'Track a material to get notified when stock moves.'} />}
      </section>
    </div>

    <section className="panel opportunities-panel">
      <div className="panel-header"><div><p className="eyebrow"><TrendingDown size={14} />{copy ? 'فرص الشراء' : 'BUYING SIGNALS'}</p><h2>{copy ? 'أقل تكلفة إجمالية' : 'Lowest-cost opportunities'}</h2><p className="panel-subtitle">{copy ? 'مواد يمكنك شراؤها الآن بأفضل نقطة دخول.' : 'Materials you can source now at the cleanest entry point.'}</p></div><div className="saving-note"><ArrowDownRight size={15} />{summary ? formatPrice(summary.averageSavings) : '—'}% {copy ? 'متوسط التوفير' : 'avg. saving'}</div></div>
      {materialsQuery.isLoading ? <LoadingRows count={3} /> : opportunities.length ? <div className="opportunity-grid">{opportunities.map((material, index) => <Link href={`/materials/${material.id}`} className="opportunity-card" key={material.id} data-testid={`card-opportunity-${material.id}`}><div className="opportunity-index">0{index + 1}</div><div className="flex-1"><p className="font-semibold text-ink">{copy ? material.nameAr : material.nameEn}</p><p className="mt-1 text-xs text-quiet">{material.sku} · {material.unit}</p></div><div className="text-right"><p className="font-mono text-sm font-semibold text-ink">{formatPrice(material.minPrice)}</p><p className="text-[11px] text-quiet">{material.supplierCount} {copy ? 'مورد' : 'suppliers'}</p></div><StatusBadge status={material.stockStatus} /></Link>)}</div> : <EmptyState title={copy ? 'لا توجد فرص الآن' : 'No buying signals yet'} copy={copy ? 'ستظهر هنا المواد ذات أفضل الأسعار.' : 'The lowest-cost material signals will appear here.'} />}
    </section>
  </div>;
}