import { useState } from 'react';
import { ArrowLeft, BellRing, CalendarDays, Check, ChevronRight, CircleDollarSign, Clock3, MapPin, PackageOpen, ShieldCheck, Truck } from 'lucide-react';
import { useCreateAvailabilityAlert, useGetMaterial, useListAvailabilityAlerts } from '@workspace/api-client-react';
import { Link, useLocation, useParams } from 'wouter';
import { useLanguage } from '@/components/buildsupply-shell';
import { ErrorState, formatDate, formatPrice, LoadingRows, OfferRow, StatusBadge } from '@/components/workspace-primitives';

export default function MaterialDetailPage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const { language } = useLanguage();
  const copy = language === 'ar';
  const [, setLocation] = useLocation();
  const [trackedLocally, setTrackedLocally] = useState(false);
  const query = useGetMaterial(id, { query: { enabled: Number.isFinite(id), queryKey: ['/api/materials', id] } });
  const alertsQuery = useListAvailabilityAlerts({ query: { queryKey: ['/api/availability-alerts'] } });
  const createAlert = useCreateAvailabilityAlert();
  const material = query.data;
  const existingAlert = alertsQuery.data?.some((alert) => alert.materialId === id && alert.status === 'active');
  const tracked = trackedLocally || existingAlert;
  const handleTrack = () => {
    createAlert.mutate({ data: { materialId: id } }, { onSuccess: () => setTrackedLocally(true) });
  };
  if (query.isLoading) return <div className="workspace-page"><LoadingRows count={6} /></div>;
  if (query.isError || !material) return <div className="workspace-page"><ErrorState detail onRetry={() => query.refetch()} /></div>;
  const offers = [...material.offers].sort((a, b) => a.totalCost - b.totalCost);
  return <div className="workspace-page">
    <div className="detail-breadcrumb"><Link href="/materials" className="text-link" data-testid="link-back-materials"><ArrowLeft size={15} />{copy ? 'العودة إلى المواد' : 'Back to materials'}</Link><ChevronRight size={14} /><span>{material.sku}</span></div>
    <section className="detail-hero">
      <div className="detail-title"><div className="detail-material-icon"><PackageOpen size={28} strokeWidth={1.5} /></div><div><div className="flex flex-wrap items-center gap-3"><p className="eyebrow">{material.category}</p><StatusBadge status={material.stockStatus} /></div><h1>{copy ? material.nameAr : material.nameEn}</h1><p className="detail-sku">{material.sku} · {copy ? `الوحدة: ${material.unit}` : `Unit: ${material.unit}`}</p></div></div>
      <button className={`track-button ${tracked ? 'track-button-active' : ''}`} onClick={handleTrack} disabled={tracked || createAlert.isPending} data-testid="button-track-availability"><BellRing size={17} />{createAlert.isPending ? (copy ? 'جارٍ الحفظ...' : 'Saving...') : tracked ? <><Check size={15} />{copy ? 'تتم المتابعة' : 'Tracking availability'}</> : (copy ? 'تتبع التوفر' : 'Track availability')}</button>
    </section>
    <div className="detail-layout">
      <div className="detail-main">
        <section className="panel description-panel"><div className="panel-header"><div><p className="eyebrow">{copy ? 'ملخص المادة' : 'MATERIAL BRIEF'}</p><h2>{copy ? 'مواصفات الشراء' : 'Procurement brief'}</h2></div><span className="last-updated">{copy ? 'آخر تحديث' : 'Updated'} {formatDate(material.lastUpdated, language)}</span></div><p className="description-copy">{copy ? material.descriptionAr : material.descriptionEn}</p><div className="material-facts"><div><CalendarDays size={16} /><span>{copy ? 'إعادة التوريد' : 'Next restock'}</span><strong>{formatDate(material.nextRestock, language)}</strong></div><div><CircleDollarSign size={16} /><span>{copy ? 'أقل سعر' : 'Starting from'}</span><strong>{formatPrice(material.minPrice)} {offers[0]?.currency ?? ''}<small>/{material.unit}</small></strong></div><div><Truck size={16} /><span>{copy ? 'الموردون' : 'Suppliers'}</span><strong>{material.supplierCount} {copy ? 'خيارات' : 'options'}</strong></div></div></section>
        <section className="panel offers-panel"><div className="panel-header"><div><p className="eyebrow"><span className="eyebrow-line" />{copy ? 'مقارنة الموردين' : 'SUPPLIER COMPARISON'}</p><h2>{copy ? 'التكلفة الإجمالية، لا السعر فقط' : 'Total cost, not just price'}</h2><p className="panel-subtitle">{copy ? 'يشمل الحساب التوصيل للوصول إلى قرار شراء أوضح.' : 'Delivery is included so the buying decision is clearer.'}</p></div><div className="offer-count">{offers.length} {copy ? 'عروض' : 'offers'}</div></div>{offers.length ? <div className="offers-list">{offers.map((offer, index) => <OfferRow offer={offer} best={index === 0} key={offer.id} />)}</div> : <div className="detail-empty"><Clock3 size={20} />{copy ? 'لا توجد عروض حالياً.' : 'No supplier offers available yet.'}</div>}</section>
      </div>
      <aside className="detail-side"><section className="side-card side-card-amber"><div className="side-card-icon"><BellRing size={18} /></div><p className="eyebrow">{copy ? 'توقع التوفر' : 'AVAILABILITY SIGNAL'}</p><h3>{material.stockStatus === 'out_of_stock' ? (copy ? 'راقب إعادة التوريد' : 'Watch the restock') : (copy ? 'متوفر للشراء' : 'Ready to source')}</h3><p>{material.stockStatus === 'out_of_stock' ? (copy ? 'سنخبرك بمجرد تأكيد وصول الشحنة التالية.' : 'We’ll tell you as soon as the next shipment is confirmed.') : (copy ? 'هناك مخزون متاح في شبكة الموردين الآن.' : 'Supplier network has available stock right now.')}</p><button onClick={handleTrack} disabled={tracked || createAlert.isPending} className="side-action" data-testid="button-side-track">{tracked ? (copy ? 'تمت الإضافة إلى التنبيهات' : 'Added to alerts') : (copy ? 'أضف إلى التنبيهات' : 'Add to alerts')} <ChevronRight size={15} /></button></section><section className="side-card"><p className="eyebrow">{copy ? 'في لمحة' : 'AT A GLANCE'}</p><div className="glance-row"><MapPin size={15} /><span>{copy ? 'أقرب مورد' : 'Nearest supplier'}</span><strong>{offers[0]?.distanceKm ?? '—'} km</strong></div><div className="glance-row"><ShieldCheck size={15} /><span>{copy ? 'عروض موثقة' : 'Verified offers'}</span><strong>{offers.filter((offer) => offer.verified).length}/{offers.length}</strong></div><div className="glance-row"><Clock3 size={15} /><span>{copy ? 'أسرع توصيل' : 'Fastest delivery'}</span><strong>{offers.length ? Math.min(...offers.map((offer) => offer.deliveryDays)) : '—'}d</strong></div></section></aside>
    </div>
  </div>;
}