import { useMemo, useState } from 'react';
import { Filter, Search, SlidersHorizontal, X } from 'lucide-react';
import { useListMaterials } from '@workspace/api-client-react';
import { useLanguage } from '@/components/buildsupply-shell';
import { EmptyState, ErrorState, LoadingRows, MaterialRow } from '@/components/workspace-primitives';

const categories = [
  { value: 'all', en: 'All categories', ar: 'كل الفئات' },
  { value: 'Cement & binders', en: 'Cement & binders', ar: 'الأسمنت والمواد الرابطة' },
  { value: 'Steel & rebar', en: 'Steel & rebar', ar: 'الحديد والتسليح' },
  { value: 'Finishes', en: 'Finishes', ar: 'التشطيبات' },
  { value: 'Masonry', en: 'Masonry', ar: 'المباني' },
];
const availability = [
  { value: 'all', en: 'Any availability', ar: 'كل حالات التوفر' },
  { value: 'in_stock', en: 'In stock', ar: 'متوفر' },
  { value: 'low_stock', en: 'Low stock', ar: 'مخزون منخفض' },
  { value: 'out_of_stock', en: 'Out of stock', ar: 'غير متوفر' },
] as const;

export default function Materials() {
  const { language } = useLanguage();
  const copy = language === 'ar';
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [stock, setStock] = useState<(typeof availability)[number]['value']>('all');
  const [filterOpen, setFilterOpen] = useState(false);
  const params = useMemo(() => ({ q: search || undefined, category: category === 'all' ? undefined : category, availability: stock }), [search, category, stock]);
  const query = useListMaterials(params, { query: { queryKey: ['/api/materials', params] } });
  const materials = query.data ?? [];
  return <div className="workspace-page">
    <section className="page-heading catalog-heading"><div><p className="eyebrow"><span className="eyebrow-line" />{copy ? 'فهرس المواد' : 'MATERIALS CATALOG'}</p><h1>{copy ? 'كل مادة، في مكانها' : 'Every material, in its place'}</h1><p className="heading-copy">{copy ? 'ابحث وقارن وتحقق من التوفر قبل أن يبطئك الموقع.' : 'Search, compare and verify availability before the site slows you down.'}</p></div><div className="catalog-count"><span>{materials.length}</span><small>{copy ? 'نتيجة' : 'results'}</small></div></section>
    <section className="catalog-toolbar" data-testid="section-material-filters">
      <div className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={copy ? 'ابحث بالاسم أو SKU...' : 'Search by name or SKU...'} aria-label="Search materials" data-testid="input-material-search" />{search && <button onClick={() => setSearch('')} aria-label="Clear search" data-testid="button-clear-search"><X size={15} /></button>}<kbd>⌘ K</kbd></div>
      <button className={`filter-trigger ${filterOpen ? 'filter-trigger-active' : ''}`} onClick={() => setFilterOpen(!filterOpen)} data-testid="button-toggle-filters"><SlidersHorizontal size={16} />{copy ? 'تصفية' : 'Filters'}<span className="filter-count">{[category !== 'all', stock !== 'all'].filter(Boolean).length}</span></button>
    </section>
    <section className={`filter-drawer ${filterOpen ? 'filter-drawer-open' : ''}`}>
      <div className="filter-block"><label htmlFor="category-filter"><Filter size={14} />{copy ? 'الفئة' : 'Category'}</label><select id="category-filter" value={category} onChange={(event) => setCategory(event.target.value)} data-testid="select-category-filter">{categories.map((item) => <option value={item.value} key={item.value}>{copy ? item.ar : item.en}</option>)}</select></div>
      <div className="filter-block"><label htmlFor="stock-filter">{copy ? 'التوفر' : 'Availability'}</label><select id="stock-filter" value={stock} onChange={(event) => setStock(event.target.value as typeof stock)} data-testid="select-stock-filter">{availability.map((item) => <option value={item.value} key={item.value}>{copy ? item.ar : item.en}</option>)}</select></div>
      {(category !== 'all' || stock !== 'all') && <button className="text-link clear-filters" onClick={() => { setCategory('all'); setStock('all'); }} data-testid="button-clear-filters">{copy ? 'مسح الفلاتر' : 'Clear filters'} <X size={14} /></button>}
    </section>
    <section className="panel catalog-panel">
      <div className="catalog-table-head"><span>{copy ? 'المادة' : 'Material'}</span><span>{copy ? 'الحالة' : 'Status'}</span></div>
      {query.isLoading ? <LoadingRows count={7} /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : materials.length ? <div className="material-list">{materials.map((material) => <MaterialRow key={material.id} material={material} />)}</div> : <EmptyState title={copy ? 'لا توجد مواد مطابقة' : 'No materials match that search'} copy={copy ? 'جرب مصطلحاً آخر أو أزل بعض الفلاتر.' : 'Try another term or remove one of the filters.'} />}
    </section>
  </div>;
}