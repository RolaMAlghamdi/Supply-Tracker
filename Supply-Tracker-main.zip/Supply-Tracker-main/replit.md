# BuildSupply

منصة ثنائية اللغة تساعد المهندسين على إيجاد مواد وقطع البناء، متابعة توفرها، ومقارنة الموردين حسب أقل تكلفة إجمالية.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/buildsupply/src/` — واجهة BuildSupply ومسارات لوحة المتابعة والمواد والتنبيهات.
- `artifacts/api-server/src/routes/sourcing.ts` — واجهات البيانات الخاصة بالمواد والعروض والتنبيهات.
- `lib/api-spec/openapi.yaml` — المصدر الوحيد لعقد API.
- `lib/api-client-react/src/generated/` و `lib/api-zod/src/generated/` — ملفات API المولدة.
- `artifacts/buildsupply/src/index.css` — ألوان وتنسيق الواجهة ودعم RTL.

## Architecture decisions

- الواجهة تستخدم OpenAPI أولًا مع React Query hooks مولدة بدل تعريف أنواع API يدويًا.
- يتم عرض تكلفة المورد الإجمالية (السعر + الشحن) لتجنب اختيار أرخص سعر اسميًا لكنه أعلى بعد التوصيل.
- اللغة محفوظة محليًا، ويتغير `dir` و`lang` على عنصر HTML لدعم العربية RTL بشكل صحيح.
- بيانات العروض والتنبيهات الحالية موجودة في طبقة الخدمة لتوفير تجربة MVP مكتملة قبل ربط مصادر الموردين الخارجية.

## Product

لوحة متابعة للمخزون، كتالوج بحث وتصفية للمواد، صفحة مقارنة الموردين والتوصيل، وتنبيهات لإعادة التوريد. تدعم العربية والإنجليزية وتتكيف مع الجوال.

## User preferences

لا توجد تفضيلات إضافية مسجلة.

## Gotchas

- بعد تعديل `lib/api-spec/openapi.yaml` شغّل `pnpm --filter @workspace/api-spec run codegen`.
- إعداد توليد Zod مضبوط على الإصدار 3 لأن نسخة `zod` الحالية لا تدعم صيغة `z.int()` الخاصة بـ Zod 4.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
